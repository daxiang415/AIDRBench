# Manuscript context for Main Figure 6

This file supplies the exact narrative context for the web GPT. It does not
authorise changes to the panel-data contract in `figure_6_contract.md`.

## Result carried by the figure

Technical qualification does not guarantee economic participation. The
economic screen holds the independently certified q = 0.95 capacity fixed and
calculates the annual compensation required to cover the incremental cost of
providing it. It is a development parameterized screening on 100 validation
scenarios, not a market-calibrated profitability estimate, a repeated-event
economic certificate or a new technical certificate for a scaled facility.

At a proportional 1-MW accounting scale, the four-hour certificate corresponds
to 197.27 kW of accounting capacity. Risk-adjusted break-even capacity payments
are US$246.60, US$362.75 and US$414.99 per kW-year for slack-backed,
reserved-headroom and throughput-displacing participation, respectively. A
fixed annual site-enablement coordinate creates a scale effect: for
slack-backed participation, the value including fixed site cost falls from
US$753.53 to US$126.20 per kW-year between the 0.2- and 20-MW accounting
scales, while the fixed-site-excluded value remains US$119.87 per kW-year.

The mechanism sensitivities are intentionally different across regimes.
Slack-backed response varies annual independent fresh-event exposure;
100 and 250 events are stress coordinates. Reserved-headroom response varies
economic life while holding WACC and salvage fixed. Throughput-displacing
response varies effective displaced-compute value, defined as exposure alpha
multiplied once by the declared GPU-hour value. These axes are not market
forecasts.

Longer duration raises the economic threshold while the independently
certified reference-module power declines. At the 1-MW proportional accounting
scale, risk-adjusted break-even payments for 2-, 4- and 8-hour events are
US$164.67, US$246.60 and US$437.21 per kW-year for slack-backed response;
US$280.82, US$362.75 and US$553.36 for reserved headroom; and US$247.77,
US$414.99 and US$774.37 for throughput displacement.

## Exact legend text

**Figure 6 | Participation costs bound economically offerable demand
response.** **a**, Risk-adjusted break-even capacity payment for the four-hour
q = 0.95 certificate under slack-backed, reserved-headroom and
throughput-displacing participation at proportional 0.2-, 1-, 5- and 20-MW
accounting scales. Each mode is shown excluding the declared fixed
site-enablement cost and including it as an operator-decision overlay. Scaled
kilowatts are proportional reference-module accounting quantities, not
technical certificates for the larger facilities. **b**, Mechanism
sensitivities at the 1-MW accounting scale: annual fresh-event count for
slack-backed response, economic life for reserved headroom and effective
displaced-compute value for throughput displacement. Event counts of 100 and
250 are exposure-multiplier stress coordinates. **c**, Signed contributions to
the four-hour risk-adjusted break-even payment. Positive values increase
required compensation and negative values reduce it; the risk buffer is the
residual between the mean and fifth-percentile rules. **d**, Mean break-even
payment excluding fixed site cost and risk-adjusted payment including fixed
site cost for independently certified 2-, 4- and 8-hour reference-module
capacities, shown at the 1-MW proportional accounting scale. The screen assumes
independent fresh events, credits performance only up to the offered obligation
and follows compute and energy through the episode-end clearance tail.
Monetary inputs are parameterized research-design coordinates unless
separately identified as external range anchors or product observations.

## Claims the artwork must not imply

- The 0.2-, 1-, 5- and 20-MW site coordinates are not technical certificates.
- The reported break-even values are not named-market prices or profit forecasts.
- The fifth percentile is a decision-risk rule, not a confidence interval.
- The screen samples independently cleared fresh events and is not a repeated programme.
- Reserved PCC-side cost is an abstract sensitivity; the supporting
  recovery-throughput GPU count is not a procurement requirement.
