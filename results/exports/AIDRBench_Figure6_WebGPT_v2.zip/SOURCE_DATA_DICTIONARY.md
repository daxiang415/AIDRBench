# Economic Figure 6 source-data dictionary (development v1)

## Status and scope

This dictionary documents the source-data bundle produced by
`configs/paper/nature_economic_source_data_v1.yaml`. The bundle supports the
proposed economic Figure 6 and its audit trail. It is a **development
parameterized screening** in real 2026 USD, not an economic locked-ID
certificate, a named-market price estimate or an operator profitability claim.

The repository has not yet selected a public data licence or assigned a DOI to
this bundle. Until those fields are resolved, treat it as a versioned internal
review artifact rather than a final public data deposit. No missing-value code
is used. Successful events explicitly store
`technical_failure_reasons=none_technical_success`.

## File-to-figure map

| File | Rows | Manuscript use |
| --- | ---: | --- |
| `fig6_fixed_site_overlay_scale_sensitivity.csv` | 24 | Exact plotted rows for panel a |
| `fig6_mechanism_sensitivity.csv` | 13 | Exact plotted rows for panel b |
| `fig6_break_even_decomposition.csv` | 36 | Exact plotted rows for panel c |
| `fig6_duration_break_even.csv` | 9 | Exact plotted rows for panel d |
| `fig6_technical_economic_boundary.csv` | 3 | Supporting 1-MW boundary audit; not a plotted panel |
| `fig6_paired_event_ledger.csv` | 300 | Supporting event-level physical audit; do not reaggregate for the main figure |
| `fig6_paired_interval_ledger.csv` | 33,414 | Supporting hourly physical audit; do not reaggregate for the main figure |
| `fig6_economic_parameter_provenance.csv` | 7 | Economic input, unit, formula and provenance register |
| `fig6_external_parameter_evidence.csv` | 37 | One external evidence observation and its permitted/forbidden use per row |
| `fig6_reserve_mapping_summary.csv` | 810 | Supplementary event-debt-to-recovery-throughput sensitivity |
| `source_data_manifest.json` | 1 manifest | Expected columns, rows, upstream inputs and SHA-256 for all ten CSV files |

The four main-panel tables are already reduced to their exact plotting rows.
The renderer or web GPT must not replace them with a new aggregation of the
supporting ledgers.

## Common analysis fields

| Field | Definition | Unit / allowed values |
| --- | --- | --- |
| `analysis_id` | Stable identifier of this economic protocol | `nature_economic_development_screening_v1` |
| `analysis_role` | Evidentiary role; prevents development output being called a locked certificate | `development_parameterized_screening` |
| `currency_basis` / `monetary_basis` | Real-dollar reference year | `real_2026_usd` |
| `annualization_scope` | Events are resampled as independent, fully cleared calls | `independent_fresh_events_not_continuous_programme` |
| `performance_payment_basis` | Performance revenue counts at most the scaled accounting offer in each interval | `interval_delivery_capped_at_scaled_accounting_offered_kW` |
| `reserved_capacity_basis` | Reserve-capital coordinate is expressed on the PCC side and is not a GPU count | `abstract_pcc_side_kw_sensitivity` |
| `facility_scale_interpretation` | Meaning of 0.2–20 MW rows | `proportional_reference_module_accounting_sensitivity_no_portfolio_diversification` |
| `technical_certificate_scope` | Boundary on scaled rows | `reference_module_only_not_scaled_facility_certificate` |
| `reference_module_operating_peak_kw` | Operating peak used as the proportional accounting denominator | kW; 201.000783984 |
| `facility_site_scale_mw` | Declared site-scale accounting coordinate | MW; 0.2, 1, 5 or 20 as applicable |
| `proportional_reference_module_scale_factor` | `1000 * facility_site_scale_mw / reference_module_operating_peak_kw` | dimensionless |
| `regime` | Mutually exclusive operator participation mechanism | `slack_backed`, `reserved_headroom`, `throughput_displacing` |
| `duration_h` | DR event duration with an independent technical certificate | h; 2, 4 or 8 |
| `notice_h` | Advance notice supplied to the controller | h; 0 in this protocol |
| `reliability_target` | Target probability used by the technical certificate | fraction; 0.95 |
| `technical_capacity_ceiling_kw` | Independently certified technical reduction ceiling `K_cert` | kW |
| `candidate_reduction_kw` | Economic offer evaluated in the row | kW; equals `K_cert` in every main-panel row |
| `scaled_accounting_technical_capacity_ceiling_kw` | Reference certificate multiplied by the proportional accounting scale factor | kW; not a site technical certificate |
| `scaled_accounting_candidate_reduction_kw` | Candidate multiplied by the proportional accounting scale factor | kW; accounting quantity only |
| `technical_qualification` | Certification status of the candidate | `independently_certified_ceiling` in every main-panel row |

## Panel a — `fig6_fixed_site_overlay_scale_sensitivity.csv`

One row per participation regime, site-scale coordinate and accounting
perspective at `H=4 h`, `q=0.95` and full `K_cert`.

| Field | Definition | Unit |
| --- | --- | --- |
| `accounting_perspective` | Whether one declared site-wide fixed cost is included | `excluding_fixed_site_lower_bound` or `including_fixed_site_overlay` |
| `fixed_site_enablement_annual_cost` | Declared annual site-wide coordinate applied once for positive offer | real 2026 USD year^-1 |
| `variable_enablement_cost_per_offer_kw` | Declared capacity-proportional enablement coordinate | real 2026 USD kW^-1 year^-1 |
| `fixed_site_enablement_cost_per_offer_kw` | Fixed site cost divided by scaled accounting offered capacity | real 2026 USD kW^-1 year^-1 |
| `annual_net_value_usd_per_year` | Mean annual net value at the declared zero capacity-payment reference | real 2026 USD year^-1 |
| `annual_net_value_p05_usd_per_year` | Fifth-percentile annual net value at the declared zero capacity-payment reference | real 2026 USD year^-1 |
| `break_even_capacity_payment_per_kw_year` | Mean-rule capacity payment after the selected fixed-site perspective | real 2026 USD kW^-1 year^-1 |
| `risk_adjusted_break_even_capacity_payment_per_kw_year` | Fifth-percentile-rule capacity payment after the selected fixed-site perspective | real 2026 USD kW^-1 year^-1 |

## Panel b — `fig6_mechanism_sensitivity.csv`

One predeclared driver is varied per regime while unrelated coordinates remain
fixed. The normalized coordinate is only a visual alignment device; the three
drivers do not share a physical unit.

| Field | Definition | Unit / allowed values |
| --- | --- | --- |
| `driver_id` | Machine-readable varied mechanism | `annual_event_count`, `economic_life_years`, `effective_displaced_compute_value_per_gpu_h` |
| `driver_label` | Human-readable driver label | text |
| `driver_value` | Actual physical/economic coordinate | see `driver_unit` |
| `driver_unit` | Unit of `driver_value` | `fresh_events_per_year`, `years`, or `real_2026_USD_per_GPU_hour` |
| `driver_value_display` | Label intended for the figure endpoint/tick | text |
| `driver_normalized_position` | Monotone 0–1 display position within that regime's declared range | dimensionless; not a shared physical scale |
| `risk_adjusted_break_even_capacity_payment_per_kw_year` | Fifth-percentile-rule break-even at the declared driver setting | real 2026 USD kW^-1 year^-1 |
| `annual_event_count_class` / `annual_event_count_is_stress` | Separates plausible 1/12/50-event coordinates from 100/250 stress coordinates | text / Boolean |
| `opportunity_exposure_alpha` | Fraction of deferred compute exposed to displacement value | fraction |
| `value_per_gpu_h` | Declared GPU-hour value coordinate | real 2026 USD GPU-h^-1 |
| `effective_displaced_compute_value_per_gpu_h` | Product `alpha * value_per_gpu_h`; plotted throughput driver | real 2026 USD GPU-h^-1 |

## Panel c — `fig6_break_even_decomposition.csv`

The table is already long-form: one row per regime and signed component.
Positive contributions raise the required capacity payment; negative
contributions are non-capacity credits. Do not infer or reverse the sign from
the component name.

| Field | Definition | Unit |
| --- | --- | --- |
| `component_id` | Stable accounting component identifier | text |
| `component_label` | Display label | text |
| `contribution_per_kw_year` | Signed component contribution to risk-adjusted break-even | real 2026 USD kW^-1 year^-1 |
| `risk_adjusted_break_even_capacity_payment_per_kw_year` | Total to which all signed component rows for that regime must sum | real 2026 USD kW^-1 year^-1 |

Allowed `component_id` values are `fixed_site_enablement_cost`,
`variable_enablement_cost`, `reserve_annual_cost`,
`opportunity_cost`, `delay_cost`, `sla_cost`, `checkpoint_cost`,
`penalty_cost`, `performance_credit`, `energy_credit_or_cost`,
`connection_credit` and `risk_buffer`.

## Panel d — `fig6_duration_break_even.csv`

One row per regime and independently certified duration. The absent durations
were not evaluated and must not be interpolated.

| Field | Definition | Unit |
| --- | --- | --- |
| `break_even_capacity_payment_per_kw_year` | Mean-rule break-even at the named certified duration | real 2026 USD kW^-1 year^-1 |
| `risk_adjusted_break_even_capacity_payment_per_kw_year` | Fifth-percentile-rule break-even at the named certified duration | real 2026 USD kW^-1 year^-1 |
| `break_even_capacity_payment_excluding_fixed_site_per_kw_year` | Mean-rule lower bound excluding the site-wide fixed term | real 2026 USD kW^-1 year^-1 |
| `risk_adjusted_break_even_capacity_payment_excluding_fixed_site_per_kw_year` | Fifth-percentile-rule lower bound excluding the site-wide fixed term | real 2026 USD kW^-1 year^-1 |

## Event audit — `fig6_paired_event_ledger.csv`

Each row is a fixed-controller replay paired with a no-DR replay on the same
frozen validation scenario, random seed, job arrivals, community profile and
event. Power-derived energy is multiplied by the one-hour timestep;
`executed_gpu_h` and related work variables already have GPU-hour units and are
not multiplied by the timestep again.

| Field | Definition | Unit / allowed values |
| --- | --- | --- |
| `evaluation_split` | Frozen scenario role | validation/development only |
| `scenario_id` | Frozen scenario identifier | text |
| `scenario_hash` | Content hash binding scenario configuration and payloads | SHA-256 |
| `episode_seed` | Frozen scenario seed | integer; 20000–20099 |
| `event_id` | Event identifier in the replay | integer |
| `event_start_hour` | First active event hour | absolute episode hour |
| `event_stop_hour` | First hour after the event | absolute episode hour |
| `recovery_stop_hour` | First hour after the declared nominal recovery window | absolute episode hour |
| `confidence_level` | Confidence level attached to the technical certificate | fraction; 0.95 |
| `offer_fraction_of_technical_ceiling` | Candidate divided by `K_cert` | 1.0 in this formal ledger |
| `technical_success` | Joint event success under all declared delivery/service/rebound criteria | Boolean |
| `technical_failure_reasons` | Comma-separated failed criteria or explicit success token | text; `none_technical_success` means no failure |
| `delivery_ratio` | Event-total capped delivery divided by requested energy | fraction |
| `minimum_interval_delivery_ratio` | Minimum capped delivery/request over active settlement intervals | fraction |
| `delivered_energy_kwh` | Raw positive PCC reduction integrated over the event; may exceed obligation | kWh |
| `capped_delivered_energy_kwh` | Interval reduction capped at offered kW and integrated over the event; payment basis | kWh |
| `shortfall_energy_kwh` | `K_offer * H - capped_delivered_energy_kwh` | kWh |
| `deferred_gpu_h` | Gross no-DR execution minus controlled execution during the event, positive part only | GPU-h |
| `recovered_within_recovery_window_gpu_h` | Gross controlled catch-up from event stop to nominal recovery stop | GPU-h |
| `recovered_through_episode_end_gpu_h` | Gross controlled catch-up from event stop through episode end | GPU-h |
| `unrecovered_at_recovery_stop_gpu_h_proxy` | Deferred minus gross catch-up at nominal recovery stop, floored at zero; diagnostic only | GPU-h |
| `unrecovered_at_episode_end_gpu_h_proxy` | Deferred minus gross catch-up at episode end, floored at zero; diagnostic only | GPU-h |
| `missed_gpu_h` | Controlled minus no-DR missed work from event start through episode end | GPU-h |
| `backlog_at_recovery_stop_gpu_h` | Positive controlled-minus-no-DR backlog at nominal recovery stop | GPU-h |
| `terminal_backlog_gpu_h` | Positive controlled-minus-no-DR backlog at episode end | GPU-h |
| `incremental_backlog_area_within_recovery_gpu_h_h` | Integral of positive incremental backlog from event start to nominal recovery stop | GPU-h^2 |
| `incremental_backlog_area_through_episode_end_gpu_h_h` | Integral of positive incremental backlog from event start through episode end; economic delay-cost basis | GPU-h^2 |
| `incremental_energy_within_recovery_kwh` | Signed controlled-minus-no-DR PCC energy from event start to nominal recovery stop | kWh |
| `incremental_energy_through_episode_end_kwh` | Signed controlled-minus-no-DR PCC energy through episode end; economic energy-value basis | kWh |
| `event_peak_delta_kw` | Maximum controlled-minus-no-DR PCC power during the event | kW |
| `recovery_peak_delta_kw` | Maximum controlled-minus-no-DR PCC power in the nominal recovery window | kW |
| `checkpoint_count_or_proxy` | Count/proxy used only if checkpoint cost is enabled | count |
| `checkpoint_proxy_method` | Provenance label for the checkpoint proxy | text |
| `paired_pcc_match_max_abs_kw` | Maximum mismatch between the controlled frame's stored baseline PCC and explicit no-DR PCC | kW |
| `controlled_work_conservation_error_gpu_h` | Controlled trajectory work-balance residual | GPU-h |
| `no_dr_work_conservation_error_gpu_h` | No-DR trajectory work-balance residual | GPU-h |

`recovered_*` is **gross catch-up**, not a net debt balance. Cascading schedule
changes mean recovered work can exceed event-only `deferred_gpu_h`. Use backlog
and terminal fields to describe remaining debt.

## Interval audit — `fig6_paired_interval_ledger.csv`

Each row is one hour from event start through episode end for one paired replay.

| Field | Definition | Unit / allowed values |
| --- | --- | --- |
| `hour` | Absolute episode hour | h index |
| `relative_hour` | `hour - event_start_hour` | h |
| `event_active` | Hour lies in the DR event | Boolean |
| `recovery_active` | Environment recovery flag | Boolean |
| `within_recovery_window` | Event/recovery accounting hour before `recovery_stop_hour` | Boolean |
| `clearance_tail_active` | Post-recovery-stop hour retained until episode end | Boolean |
| `controlled_pcc_power_kw` / `no_dr_pcc_power_kw` | Paired point-of-common-coupling power | kW |
| `controlled_executed_gpu_h` / `no_dr_executed_gpu_h` | Work executed in the hourly step | GPU-h |
| `controlled_backlog_gpu_h` / `no_dr_backlog_gpu_h` | Outstanding deferrable work at the step | GPU-h |
| `controlled_missed_gpu_h` / `no_dr_missed_gpu_h` | Missed work reported in the step | GPU-h |
| `pcc_delta_kw` | Controlled minus no-DR PCC power | kW |
| `execution_delta_gpu_h` | Controlled minus no-DR executed work | GPU-h |
| `backlog_delta_gpu_h` | Controlled minus no-DR backlog | GPU-h |

Scenario, event, duration, notice and candidate identifiers have the same
definitions as in the event ledger.

## Parameter provenance — `fig6_economic_parameter_provenance.csv`

| Field | Definition |
| --- | --- |
| `input_id` | Stable economic-input family identifier |
| `description` | Human-readable definition |
| `value_or_range` | Declared value or sensitivity range |
| `unit` | Machine-readable unit description |
| `source_type` | Internal artifact or research-design sensitivity classification |
| `source_reference` / `source_url` | Upstream artifact or external location; `not_applicable` means no external market source is claimed |
| `access_date` | Date the source/reference was fixed |
| `status` | Verification or illustrative status |
| `permitted_interpretation` | Explicit claim boundary |
| `support_level` | Evidentiary class of any linked observation | `direct_market_observation`, `external_range_anchor` or `context_only` |
| `replaceability` | Whether the observation can enter a product overlay, only anchor a sensitivity, or cannot be quantitatively transferred | `product_overlay_only`, `sensitivity_only` or `not_convertible` |
| `forbidden_interpretation` | Claim that must not be made from the registered input or evidence |
| `specification_sha256` | Economic protocol hash |
| `physical_ledger_contract_sha256` | Hash of the technical/physical replay contract, deliberately excluding monetary inputs |
| `controller_config_sha256` | Fixed controller configuration hash |
| `technical_certificate_manifest_sha256` | Prior technical certificate manifest hash |
| `ledger_event_sha256` / `ledger_manifest_sha256` | Paired physical ledger integrity hashes |
| `input_source_path` / `input_source_sha256` | Exact file and content hash supplying the input |
| `external_parameter_evidence_path` / `external_parameter_evidence_sha256` | Machine-readable external evidence register and content hash |
| `formula` | Accounting formula using the input |

## External evidence — `fig6_external_parameter_evidence.csv`

Each row is one external observation, not one model parameter. Multiple values
from one report remain separate rows, and every row contains one source URL.

| Field | Definition |
| --- | --- |
| `evidence_id` | Stable observation identifier referenced by the parameter register |
| `input_id` | Economic input family that the observation may contextualise |
| `parameter_family` | Narrow economic or market concept addressed |
| `source_title` / `source_organization` / `source_url` | Exact external provenance |
| `publication_or_reporting_year` / `access_date` | Source and retrieval dates |
| `observed_value` / `unit` / `currency_year` | Observation exactly as registered, before any permitted comparison |
| `support_level` | Direct product observation, external range anchor or context only |
| `replaceability` | Product overlay only, sensitivity only or not quantitatively convertible |
| `permitted_use` | Narrow manuscript use supported by the evidence |
| `forbidden_interpretation` | Explicit transfer or calibration claim that the evidence does not support |

The table must never be used to combine prices and penalties from different
markets into one tariff, infer target-operator contribution margin from cloud
list price, treat accounting life as physical GPU life or convert nameplate
server power directly into flexible PCC capacity.

## Reserve mapping — `fig6_reserve_mapping_summary.csv`

This supporting sensitivity maps event-end paired backlog debt to concurrent
recovery throughput. It is not plotted in Main Figure 6.

| Field | Definition | Unit / boundary |
| --- | --- | --- |
| `event_end_paired_backlog_debt_gpu_h` | Positive controlled-minus-no-DR backlog at relative hour H-1 | GPU-h |
| `event_debt_quantile` / `event_debt_quantile_label` | Quantile of event-end debt across paired events | 0.50/q50 or 0.95/q95 |
| `recovery_target_h` | Declared debt-clearance target | h; 2, 4, 8, 12 or 24 |
| `recovery_execution_efficiency` | Fraction of nominal concurrent GPU throughput assumed usable for recovery | 0.70, 0.85 or 1.00 |
| `continuous_recovery_throughput_equivalent_gpu_count` | Debt divided by target and efficiency | equivalent concurrent GPUs |
| `recovery_throughput_equivalent_gpu_count_node_rounded` | Continuous count rounded upward to four-GPU nodes | equivalent GPUs, not a required fleet |
| `recovery_throughput_equivalent_node_count` | Node-rounded count divided by four | equivalent nodes |
| `gpu_count_interpretation` | Normative label preventing procurement interpretation | `recovery-throughput-equivalent reserved GPU count` |
| `installed_it_power_kw` / `installed_facility_power_kw` | Power of the node-rounded equivalent under declared board/node/PUE assumptions | kW |
| `recovery_dynamic_facility_power_kw` | Active-minus-idle dynamic facility power at the continuous equivalent count | kW |
| `capital_cost_evaluation` / `capital_cost` | Hardware capital calculation gate | `disabled` / blank |

Active board power is anchored to the measured RTX PRO 6000 artifact.
Node-overhead and PUE values are explicit engineering assumptions. These rows
do not estimate H100/H200 performance, prove electrical deliverability or
recommend dedicated hardware procurement.

## Methods and provenance summary

The physical ledger replays each frozen validation scenario twice: a fixed
robust-MPC controller and a paired no-DR controller. The technical ceiling is
read from the existing q=0.95 locked-ID certificate, but no locked scenario
payload is reopened. Replay executes the certificate's source-and-lock-pinned
Git snapshot; current code performs only the audited economic aggregation.
Economic evaluation bootstraps independent fresh events and publishes outputs
atomically. Each manifest binds the specification, input and output hashes.

The complete normalized assumptions are in
`configs/economics/economic_participation_v1.yaml`,
`configs/economics/cost_parameter_grid_v1.yaml` and
`configs/economics/market_archetypes_v1.yaml`. Software dependencies are locked
in `uv.lock`; the runtime and Git identifiers are recorded in the ledger and
evaluation manifests.

## Access, licence and citation fields still to resolve

- Public repository/DOI: not yet assigned.
- Dataset version: development v1; use the Git commit and manifest hashes until
  a release tag exists.
- Data licence: not yet selected; do not infer one from repository visibility.
- Preferred dataset citation: pending author list, repository and DOI.
- Third-party source conditions remain those of Alibaba Cluster Trace and NREL;
  this bundle contains processed simulation outputs, not redistributed raw
  third-party archives.
