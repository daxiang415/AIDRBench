# README FIRST — Web GPT contract for Main Figure 6

This package contains the exact, hash-bound data for the proposed Main
Figure 6. The **formal artwork must be generated in the web GPT**, using its
data-analysis environment to read the supplied CSV files. Repository-side
renderers, text-to-image models, manual transcription and guessed coordinates
are not authorised for the formal figure.

## Scientific message

An independently certified demand-response commitment becomes economically
offerable only when compensation covers the participation mechanism's
incremental costs. Fixed site enablement is a site-level overhead, so its
per-kW effect depends on the accounting scale; reserved compute and displaced
compute are separate mechanisms, not interchangeable cost labels.

Working title:

> **Economic participation is bounded by site scale and the cost of reserved
> or displaced compute**

This is a real-2026-USD **development parameterized screening**. It is not an
economic locked-ID certificate, a forecast of operator profit, a price estimate
for a named market, or a technical certificate for a 0.2–20 MW facility.

## Stop-first integrity gate

Before drawing anything:

1. Open `source_data/source_data_manifest.json`.
2. Verify that every listed CSV exists under `source_data/`.
3. Recompute every CSV SHA-256 and compare it with `output_sha256`.
4. Check every observed row count and ordered column list against the manifest.
5. Confirm `software.git.working_tree_dirty` is `false`.
6. Confirm each main-panel table has exactly the panel assignment below.

Stop and report the mismatch if any check fails. Do not repair a CSV, remove a
row, fill a blank, rename a category or silently continue.

## Exact file-to-panel map

| Panel | Exact plot table | What one row represents |
| --- | --- | --- |
| a | `fig6_fixed_site_overlay_scale_sensitivity.csv` | One regime × declared site-scale coordinate × accounting perspective |
| b | `fig6_mechanism_sensitivity.csv` | One predeclared mechanism-driver coordinate |
| c | `fig6_break_even_decomposition.csv` | One signed accounting component for one regime |
| d | `fig6_duration_break_even.csv` | One regime × independently certified duration |

The manifest's `row_count` is authoritative. Do not hard-code a row count from
this prose. The four plot CSVs are already reduced to exact plotted rows: the
web GPT must not derive replacement panel values from the event or interval
ledgers.

Supporting files, which are not new hidden sources for panel aggregation:

| File | Purpose |
| --- | --- |
| `fig6_technical_economic_boundary.csv` | Reference 1 MW accounting-coordinate boundary and mean/risk values without the full scale sweep |
| `fig6_paired_event_ledger.csv` | One paired no-DR versus controlled record per development event |
| `fig6_paired_interval_ledger.csv` | Exact hourly trajectories behind the paired event ledger |
| `fig6_economic_parameter_provenance.csv` | Model-input definitions, formulas, claim boundaries and source linkage |
| `fig6_external_parameter_evidence.csv` | External observations used only as documented anchors or comparators |
| `fig6_reserve_mapping_summary.csv` | Supplementary event-end debt → recovery-throughput-equivalent GPU/power sensitivity; capital cost is disabled |

Read `SOURCE_DATA_DICTIONARY.md` for every field definition and
`protocol/figure_6_contract.md` for the evidentiary boundaries.

## Non-negotiable transformation rules

- Plot numeric coordinates from the four panel CSVs at full precision.
- Do not recompute, aggregate, interpolate, smooth, extrapolate, impute or
  invent a coordinate.
- Connecting lines may guide the eye only between declared coordinates. They
  do not license values between coordinates.
- Display annotations may be rounded, but marks must use unrounded CSV values.
- Do not omit a zero component in panel c: render it as a zero-line tick or
  another explicit zero mark.
- Do not merge fixed and variable enablement, reserve cost and displaced
  compute, or mean and fifth-percentile break-even rules.
- Do not label proportional accounting copies as independently certified MW.
- Do not call the recovery-throughput-equivalent GPU count a required fleet,
  firm GPU count or purchase requirement.
- Do not plot a market-price benchmark unless a later author-approved contract
  explicitly adds one.

## Shared encodings

Use this fixed order, display label and colour mapping throughout:

| Order | Machine value | Display label | Colour |
| ---: | --- | --- | --- |
| 1 | `slack_backed` | Slack-backed | `#3D9B8F` |
| 2 | `reserved_headroom` | Reserved headroom | `#776FA3` |
| 3 | `throughput_displacing` | Throughput-displacing | `#D5634E` |

Use dark ink `#24313D`, neutral grey `#75808A`, pale grey `#EEF2F4` and light
grid lines `#DCE2E6`. Use colour for regime and shape/line style for accounting
or statistical interpretation; do not encode two unrelated meanings with one
colour.

Figure-wide note, reproduced verbatim:

> Fresh-event screening; real 2026 USD. Technical certificates apply only to
> the reference module. The 1 MW and other site-scale coordinates are
> proportional-reference-module accounting sensitivities with no assumed
> portfolio diversification.

The fifth-percentile rule is a bootstrap annual net-value risk rule. It is not
a confidence interval, standard deviation, standard error or p value.

## Panel a — fixed-site overlay and accounting scale (hero panel)

**Question:** How much of the risk-adjusted break-even payment comes from
applying one fixed site cost at different proportional accounting scales?

Use every row in `fig6_fixed_site_overlay_scale_sensitivity.csv`.

- x coordinate: `facility_site_scale_mw`, using the exact declared 0.2, 1, 5
  and 20 MW coordinates. A log-scaled x axis is preferred; show all four ticks.
- y coordinate:
  `risk_adjusted_break_even_capacity_payment_per_kw_year`.
- colour: `regime`.
- accounting perspective:
  - solid line + filled marker = `including_fixed_site_overlay`;
  - dashed line + open marker = `excluding_fixed_site_lower_bound`.
- Directly label both accounting perspectives and the regime endpoints.
- If space permits, annotate
  `fixed_site_enablement_cost_per_offer_kw` at the 0.2 and 20 MW coordinates.

Axis labels:

- **Proportional accounting site scale (MW)**
- **Risk-adjusted break-even capacity payment (real 2026 USD kW⁻¹ year⁻¹)**

Do not say that these site sizes were technically certified. The independent
technical certificate remains the reference-module
`technical_capacity_ceiling_kw`; the plotted economics use
`scaled_accounting_technical_capacity_ceiling_kw` solely as a proportional
accounting denominator.

## Panel b — predeclared mechanism sensitivities

**Question:** Which regime-specific mechanism changes the risk-adjusted
break-even threshold while unrelated coordinates remain fixed?

Use every row in `fig6_mechanism_sensitivity.csv`. Because the three drivers
have different units, use three aligned lanes or small sub-axes rather than one
falsely shared physical x axis.

- Slack-backed x coordinate: `annual_event_count`. Use
  `annual_event_count_class` and `annual_event_count_is_stress` visibly:
  1, 12 and 50 events/year are plausible screening coordinates; 100 and 250
  are **exposure-multiplier stress tests**, shown with a distinct open/crossed
  marker and labelled “stress”. They are not chronological dispatch rates.
- Reserved-headroom x coordinate: `economic_life_years`, exposed through
  `driver_value`; this one-factor lane holds WACC and salvage fixed as declared.
- Throughput-displacing x coordinate:
  `effective_displaced_compute_value_per_gpu_h`. This is
  `opportunity_exposure_alpha × value_per_gpu_h`; do **not** use alpha alone as
  the displayed physical x axis.
- y coordinate for every lane:
  `risk_adjusted_break_even_capacity_payment_per_kw_year`.

Label each lane with its physical unit. `driver_normalized_position` may be
used only to align lane geometry; it is never the reported scientific x
variable.

## Panel c — signed break-even decomposition

**Question:** Which incremental costs and non-capacity credits compose the
risk-adjusted break-even threshold at the declared 1 MW proportional
accounting coordinate?

Use every row in `fig6_break_even_decomposition.csv`.

- Draw one signed stacked bar per regime with a visible zero line.
- y coordinate: `contribution_per_kw_year` exactly as signed.
- Positive values raise required compensation; negative values are credits.
- `fixed_site_enablement_cost` and `variable_enablement_cost` are separate
  components and must have separate legend entries and marks.
- Reserve cost belongs only to reserved headroom; displaced-compute
  opportunity cost belongs only to throughput displacement. Do not combine
  them.
- Draw the total
  `risk_adjusted_break_even_capacity_payment_per_kw_year` as a separate open
  diamond for each regime.
- Before drawing, verify within 1e-6 USD kW⁻¹ year⁻¹ that every regime's signed
  component sum equals its repeated total. Stop if it does not.
- Preserve zero-valued rows as explicit zero marks so the visual remains
  one-to-one with the CSV.

Axis: **Contribution to break-even payment (real 2026 USD kW⁻¹ year⁻¹)**.

## Panel d — certified duration and the 1 MW accounting scope

**Question:** How does break-even compensation vary across durations that have
separate reference-module technical certificates?

Use every row in `fig6_duration_break_even.csv`.

- Use categorical x positions from the exact `duration_h` values in the CSV.
  Do not create 1, 3, 5, 6 or 7 h rows.
- Open circle:
  `break_even_capacity_payment_excluding_fixed_site_per_kw_year`.
- Filled diamond:
  `risk_adjusted_break_even_capacity_payment_per_kw_year`.
- Colour by regime and connect only rows that exist.
- Above each duration, add a compact two-line annotation after verifying the
  values are identical across regimes:
  - `Reference certificate: <technical_capacity_ceiling_kw> kW`;
  - `1 MW proportional accounting: <scaled_accounting_technical_capacity_ceiling_kw> kW`.
- State in-panel that the second number is not a 1 MW technical certificate.

Axes:

- **Independently certified event duration (h)**
- **Break-even capacity payment (real 2026 USD kW⁻¹ year⁻¹)**

This panel deliberately contrasts the fixed-site-excluded mean-style lower
bound with the full fixed-site-overlay risk rule. The marker labels must name
both quantities; do not shorten them to ambiguous “mean” and “risk” alone.

## Composition and delivery

- Nature Communications double-column width: 183 mm.
- White background; four panels labelled **a–d**.
- Make panel a the largest visual entry point; panels b–d are subordinate
  mechanism/accounting checks.
- Minimum final text size: 7 pt for primary labels and 6.5 pt for secondary
  annotations.
- Avoid 3-D effects, gradients, decorative icons, shadows and dense box
  borders.
- Return editable SVG and PDF, 600 dpi LZW TIFF, a PNG preview, and the exact
  code/notebook or machine-readable generation record used by the web GPT.
- The web GPT must not overwrite any supplied CSV or manifest.

## Final web-GPT QA checklist

1. Every mark traces to one row and named column in its panel CSV.
2. All manifest hashes, row counts and ordered columns passed verification.
3. Panel a shows all declared site scales and both accounting perspectives.
4. Panel b labels 100/250 events/year as stress and uses `alpha × v` for the
   throughput lane.
5. Panel c shows fixed and variable enablement separately and closes its signed
   identity.
6. Panel d distinguishes the reference-module certificate from the 1 MW
   proportional accounting coordinate.
7. No market price, untested duration, extra site scale, missing component or
   GPU purchase requirement was invented.
8. All figure text remains editable and unclipped at 183 mm.

If any item fails, return an error report instead of a formal figure.
