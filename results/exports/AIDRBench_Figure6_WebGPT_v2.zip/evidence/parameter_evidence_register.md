# Economic-parameter evidence register

**Evidence freeze date:** 2026-09-04  
**Applies to:** `nature_economic_development_screening_v1`  
**Machine-readable companions:** `data/economics/source_register.csv` and
`data/economics/external_parameter_evidence.csv`

## 1. Purpose and claim boundary

This register separates three different things that must not be conflated:

1. an input that is measured or certified inside AIDRBench;
2. an external observation that can anchor a sensitivity range or a named-market overlay;
3. a contextual source that demonstrates a mechanism but cannot be converted into the model's dollar input.

The current economic analysis remains a parameterized screening analysis. None of the sources below turns the abstract `real_2026_usd` coordinates into a calibrated cost base for a named AI-data-centre operator. In particular, public GPU rental prices are not contribution margins, server procurement prices are not reserved-PCC-kW costs, and prices from different demand-response programmes must not be combined into a synthetic tariff.

`source_register.csv` deliberately retains exactly seven `input_id` rows. Those
identifiers are part of the evaluator's machine interface and each maps to one
model input family. `external_parameter_evidence.csv` stores one external
source/observed value per row and joins many-to-one through `input_id`.
Inputs for which no transferable evidence was found, notably the present delay
and SLA dollar coordinate, deliberately have no invented evidence row.

## 2. Evidence and replacement vocabulary

### `support_level`

| Value | Meaning |
| --- | --- |
| `verified_internal_artifact` | Hash-pinned AIDRBench result; valid for the stated internal estimand only. |
| `direct_market_observation` | A price or rule published by the vendor, system operator, regulator or official statistics agency. It remains product-, place- and date-specific. |
| `external_range_anchor` | An authoritative external range that is useful for sensitivity design but is not a measurement of this operator or site. |
| `context_only` | The source supports the existence or direction of a mechanism, but its number cannot be transferred into the present model. |

### `replaceability`

| Value | Meaning |
| --- | --- |
| `direct_internal_input` | May be used exactly as the stated technical input. |
| `product_overlay_only` | May be used only in a separately named market/vendor scenario with matching rules and units. |
| `sensitivity_only` | May justify a range, but not a point estimate or profitability claim. |
| `not_convertible` | Must not replace the current model parameter without an additional physical or accounting mapping. |

## 3. Decision table

| Parameter family | Current coordinate | Best available evidence status | Can replace the current coordinate? | Placement |
| --- | --- | --- | --- | --- |
| Technical ceiling `K_cert` | duration-specific, `q=0.95` | Verified internal certificate | Yes, only as technical ceiling | Main text and Methods |
| Economic life | 3–6 y; 4 y reference | Accounting-life range anchor | No point replacement; range only | SI; one short Methods sentence |
| WACC | 4–12%; 8% reference | Cross-sector finance anchor only | No; sensitivity only | SI |
| Salvage | 0–20%; 10% reference | No target-operator evidence | No; sensitivity only | SI |
| Reserved-capacity cost | USD 2,500 per abstract reserved PCC kW | Whole-system procurement and building-ADR context only | No | SI |
| Compute value | USD 0.50 per GPU-h | Direct public list prices are gross-revenue ceilings | Only in a named gross-price overlay, never as margin | SI; optionally a secondary panel |
| Delay/SLA cost | USD 0.005 per GPU-h-h | No transferable public operator cost found | No | SI |
| Checkpoint cost | USD 0 per event | Literature shows highly stack-dependent overhead | No; zero is a Model A omission/lower-bound coordinate | SI limitation |
| Programme enablement | USD 25,000 per site-y plus zero variable term | Historical ADR first-cost evidence | No; requires capex/opex separation and CPI/scope mapping | SI |
| Capacity/performance/penalty | declared research grid | Direct official market observations | Only as one internally consistent named product overlay | Main text may show one overlay; full rules in SI |
| Flexible-interconnection value | zero | Mechanism is official; monetary value is project-specific | No generic replacement | Discussion/SI |
| Electricity price | USD 0.10/kWh | Direct national-average observation | Range anchor only, not site tariff | SI |

## 4. Detailed evidence by parameter

### 4.1 GPU and server economic life

**Primary evidence**

- **LIFE-CRWV-2025 — CoreWeave 2025 Form 10-K.** CoreWeave reports that it changed the estimated useful life of data-centre computing equipment from five to six years effective 1 January 2023, and lists technology equipment at six years. [SEC filing](https://www.sec.gov/Archives/edgar/data/1769628/000176962826000104/crwv-20251231.htm)
- **LIFE-AMZN-2025 — Amazon 2025 Form 10-K.** Amazon reports servers and networking equipment at five to six years; it changed servers from five to six years in 2024 and a subset of servers/networking equipment from six back to five years in 2025. [SEC filing](https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm)
- **LIFE-MSFT-2025 — Microsoft FY2025 Form 10-K.** Microsoft reports a two-to-six-year useful-life range for computer equipment. [SEC filing](https://www.sec.gov/Archives/edgar/data/789019/000095017025100235/msft-20250630.htm)

**Support level:** `external_range_anchor`  
**Replaceability:** `sensitivity_only`

**Allowed interpretation:** Public audited accounting policies support a multi-year economic-life sensitivity and make 3–6 years a defensible research range.

**Forbidden interpretation:** These are not measurements of physical GPU failure, optimal AI-accelerator replacement, or the useful life of the four RTX PRO 6000 Blackwell Max-Q GPUs in this study. The 4-year reference remains a design coordinate rather than an observed operator estimate.

### 4.2 WACC, discount rate and salvage

**Primary evidence**

- **WACC-NREL-2024 — NREL 2024 Annual Technology Baseline, Financial Cases and Methods.** NREL explicitly uses WACC as the discount-rate input to the capital-recovery factor. In its R&D-only case, nominal after-tax WACC spans 6.01–8.21% for renewable technologies and is 8.0% for natural gas. [NREL ATB](https://atb.nrel.gov/electricity/2024/financial_cases_%26_methods)
- **FINANCE-CRWV-2025 — CoreWeave 2025 Form 10-K.** CoreWeave
  disclosed 9.25% senior notes due 2030, 9.00% senior notes due 2031,
  and delayed-draw facilities priced at SOFR plus 4.00–4.25 percentage
  points. These are debt terms, not WACC. [SEC filing](https://www.sec.gov/Archives/edgar/data/1769628/000176962826000104/crwv-20251231.htm)

**Support level:** `external_range_anchor`  
**Replaceability:** `sensitivity_only`

**Allowed interpretation:** The source validates the capital-recovery-factor method and shows that a one-factor WACC sensitivity around 8% is numerically plausible in an infrastructure-finance context.

**Forbidden interpretation:** NREL's values describe generation projects, not an AI-cloud operator. CoreWeave's debt coupon or floating-rate spread is only one component of financing and is not WACC. No source identified here supports 8% as the measured cost of capital for the target data centre, and no external source currently supports the 10% salvage reference. WACC and salvage therefore remain orthogonal sensitivity axes.

### 4.3 Server/GPU capex and reserved headroom

**Primary evidence**

- **CAPEX-B200-2025 — University of Strathclyde contract award.** The award covers one NVIDIA DGX B200 with eight Blackwell GPUs and associated components, software and service for GBP 281,446.96 excluding VAT. Contract concluded 5 June 2025; notice published 31 July 2025. [Public Contracts Scotland](https://www.publiccontractsscotland.gov.uk/search/show/search_view.aspx?ID=JUL535955)
- **CAPEX-H100-2024 — CNR DGX H100 tender.** The public tender gives an estimated value of EUR 450,000 excluding VAT for one DGX H100 server; the page does not report a final contracted value. [EU public procurement record](https://op.europa.eu/en/web/public-procurement/procurement-details/-/procurement/0a6bfa26-e1c4-43bc-9fdd-8ce466a4f5eb)
- **POWER-H100-NVIDIA — NVIDIA DGX H100 datasheet.** The system contains eight H100 GPUs and lists maximum system input power of approximately 10.2 kW and three years of included support. [NVIDIA datasheet](https://www.nvidia.com/content/dam/en-zz/Solutions/Data-Center/nvidia-dgx-h100-datasheet.pdf)

**Support level:** `context_only`  
**Replaceability:** `not_convertible`

**Allowed interpretation:** These observations show the order of magnitude and bundled nature of public AI-system procurement. They motivate explicit hardware, support, integration and currency-year scope.

**Forbidden interpretation:** Do not divide the contract value by eight and call the quotient a GPU-card price. Do not divide it by maximum input power and call the quotient reserved flexible-PCC-kW cost. Nameplate input power is not measured controllable DR capacity, and a procurement bundle is not the incremental cost of keeping headroom. A valid conversion would require, at minimum, a hardware-to-measured-controllable-kW map, PUE/PCC treatment, reserve fraction, utilization counterfactual, support allocation, exchange rate and inflation conversion.

**Model decision:** Retain USD 2,500 per abstract reserved PCC kW as a sensitivity coordinate. Do not relabel it as empirical.

### 4.4 Compute value and contribution margin

**Primary evidence**

- **COMPUTE-AWS-2026 — AWS EC2 Capacity Blocks for ML.** On the access date, effective per-accelerator hourly rates included H100 at USD 4.720 in Tokyo and USD 5.191 in several US regions, H200 at USD 5.970–6.865, and B200 at USD 12.355–12.870. [AWS price page](https://aws.amazon.com/ec2/capacityblocks/pricing/)
- **COMPUTE-LAMBDA-2026 — Lambda GPU instances.** On the access date, list prices included H100 PCIe at USD 3.29/GPU-h, H100 SXM at USD 4.19–4.29/GPU-h, B200 at USD 6.89–6.99/GPU-h, A6000 at USD 1.09/GPU-h and legacy Quadro RTX 6000 at USD 0.69/GPU-h. Taxes may apply. [Lambda price page](https://lambda.ai/instances)
- **COMPUTE-CRWV-2025 — CoreWeave 2025 Form 10-K.** CoreWeave reports company-level revenue and cost lines and describes committed contracts as generally one-to-six-year take-or-pay arrangements. These aggregates do not isolate marginal GPU-hour contribution. [SEC filing](https://www.sec.gov/Archives/edgar/data/1769628/000176962826000104/crwv-20251231.htm)

**Support level:** `direct_market_observation` for list prices  
**Replaceability:** `product_overlay_only`

**Allowed interpretation:** Public rental prices can define named gross-revenue-ceiling scenarios and show that the value of compute varies substantially by accelerator, region, commitment and provider.

**Forbidden interpretation:** A list price is not contribution margin, internal value of a training hour, net profit, displaced customer revenue or DR interruption loss. It includes hardware, networking, storage, software, operations, provider margin and commercial terms. Company-level financial statements cannot recover the marginal value of one GPU-hour.

**Model decision:** Retain USD 0.50/GPU-h as a sensitivity coordinate. A future operator-specific replacement must document utilization, contract status, variable energy/operations cost, service credits, and whether delayed work is actually displaced rather than recovered.

### 4.5 Delay, SLA and missed-work cost

No authoritative public source identified in this audit provides a transferable USD-per-GPU-hour-hour delay cost or a marginal SLA loss for the workload used here.

**Support level:** `context_only`  
**Replaceability:** `sensitivity_only`

**Allowed interpretation:** Backlog area is a physical delay proxy that can be priced parametrically.

**Forbidden interpretation:** The present USD 0.005/GPU-h-h coordinate must not be described as an observed SLA penalty, customer willingness-to-pay, or lost revenue. Zero missed-work and terminal-backlog costs are lower-bound modelling choices, not evidence that missed work is costless.

### 4.6 Checkpoint overhead

**Primary evidence**

- **CKPT-ROJAS-2020 — Rojas et al., _A Study of Checkpointing in Large Scale Training of Deep Neural Networks_.** With a checkpoint every five epochs and 4–32 GPUs, reported training-time overhead varied from 3.8% to 22.1% for Chainer, 1.2% to 5.5% for PyTorch and 0.3% to 6.8% for TensorFlow. [arXiv:2012.00825](https://doi.org/10.48550/arXiv.2012.00825)
- **CKPT-DEEPFREEZE-2020 — Nicolae et al., _DeepFreeze_.** The study reports an order-of-magnitude reduction in blocking checkpoint overhead and strong runtime-overhead reductions relative to baseline approaches on its evaluated HPC stack. [DOI: 10.1109/CCGrid49817.2020.00-76](https://doi.org/10.1109/CCGrid49817.2020.00-76)
- **CKPT-CHECKMATE-2026 — Bhardwaj et al., _Checkmate_.** The NSDI 2026 system performs per-iteration checkpointing with training throughput comparable to an ideal no-checkpoint baseline by using network gradient replication and a CPU shadow cluster; at matched frequency it reports 1.3–6.5 times the throughput of compared systems. [USENIX open-access paper](https://www.usenix.org/conference/nsdi26/presentation/bhardwaj)

**Support level:** `external_range_anchor` for mechanism sensitivity, not a dollar input  
**Replaceability:** `not_convertible` for `checkpoint_cost_per_event`

**Allowed interpretation:** Checkpoint overhead can range from negligible under a specialized architecture to above 20% under other frameworks and scales. This supports treating checkpoint design as a future sensitivity or measured system input.

**Forbidden interpretation:** Do not apply 22.1% to every DR event; the cited experiment checkpointed every five epochs and used different models, frameworks and hardware. Do not interpret Checkmate as evidence that the present stack has zero overhead; it requires a specialized network/CPU-shadow architecture.

**Model decision:** `checkpoint_cost_per_event = 0` is explicitly a Model A omission/lower-bound coordinate, not an empirical estimate. Any nonzero dollar value requires measurement of checkpoint time, lost/recovered work and the applicable compute value on the target stack.

### 4.7 Programme enablement cost

**Primary evidence**

- **ENABLE-LBNL-2015 — Piette et al., _Costs to Automate Demand Response_.** Across 56 installed automated-DR systems, the median reported first cost was about USD 200/kW, with approximately order-of-magnitude dispersion around the median. The study focuses mostly on commercial buildings, with some industrial facilities. [LBNL-1003924](https://eta-publications.lbl.gov/publications/costs-automate-demand-response)
- **ENABLE-LBNL-2017 — _Demand Response Advanced Controls Framework and Cost Assessment_.** Reported commercial control estimates span USD 62–310/kW enabled, and hardware/communications for large commercial HVAC and refrigerated-warehouse resources average about USD 2,066/site. The report averages vendor, aggregator and utility inputs and explicitly does not establish a competitive quote for an AI data centre. [LBNL report PDF](https://eta-publications.lbl.gov/sites/default/files/demand_response_advanced_controls_framework_and_cost_assessment_final_published.pdf)
- **ENABLE-NYC-2014 — New York City Auto-DR demonstration.** Four large-commercial-building demonstrations reported automation/enablement costs of USD 70–725/kW shed. [LBNL project record](https://eta.lbl.gov/publications/demonstration-automated-price)

**Support level:** `context_only` for this application  
**Replaceability:** `not_convertible`

**Allowed interpretation:** Automated DR has both site-fixed and capacity-dependent first costs, and historical field evidence shows wide dispersion. The sources support separating site capex, variable enablement capex and recurring programme opex.

**Forbidden interpretation:** Historical commercial-building first costs are not annual AI-data-centre programme costs. They do not include the same control stack, cybersecurity, telemetry, market registration, staffing or maintenance boundary. Do not use them to validate the present USD 25,000/site-year coordinate, and do not convert old dollars to `real_2026_usd` without an explicit CPI series and transformation.

**Model decision:** Keep USD 25,000/site-year as a declared sensitivity. In a calibrated version, first cost should be annualized separately from recurring opex; the two must not be added as if they shared the same time basis.

### 4.8 DR capacity payment, performance settlement and non-performance penalty

**Primary evidence**

- **MARKET-PJM-2027/28 — PJM Base Residual Auction.** The 2027/2028 auction cleared at USD 333.44 per UCAP MW-day. Multiplying by 365 and dividing by 1,000 gives USD 121.71 per UCAP kW-year. PJM also reports that demand response's ELCC class rating increased to 92% for that auction. [PJM auction report](https://www.pjm.com/-/media/DotCom/markets-ops/rpm/rpm-auction-info/2027-2028/2027-2028-bra-report.pdf)
- **MARKET-ISONE-FCA18 — ISO New England Forward Capacity Auction.** FCA18 cleared at USD 3.580/kW-month across all zones and import interfaces, equal to USD 42.96/kW-year before resource-specific qualification or settlement effects. [ISO-NE market statistics](https://www.iso-ne.com/about/key-stats/markets)
- **MARKET-NYISO-SCR — NYISO Installed Capacity Manual.** A Special Case Resource's monthly Minimum Payment Nomination cannot exceed USD 500/MWh. It is a strike/minimum-guarantee mechanism tied to dispatch, verified load reduction and a payment period of at least four hours, not a generic performance adder. [NYISO ICAP Manual](https://www.nyiso.com/documents/20142/2923301/icap_mnl.pdf)
- **MARKET-ISONE-PFP — ISO-NE Pay-for-Performance.** Capacity scarcity is settled at five-minute information intervals using a performance score; resources above the requirement receive payments and those below it incur charges, subject to stop-loss provisions. [ISO-NE PFP guide](https://www.iso-ne.com/markets-operations/markets/forward-capacity-market/fcm-participation-guide/about-fcm-pay-for-performance-pfp-rules)

**Support level:** `direct_market_observation`  
**Replaceability:** `product_overlay_only`

**Allowed interpretation:** These sources support realistic orders of magnitude and, more importantly, show that capacity accreditation, event duration, metering, baseline, availability and penalty rules are part of the product definition.

**Forbidden interpretation:** Do not add PJM capacity revenue, NYISO minimum payment and ISO-NE PFP settlement in one artificial programme. Do not treat `K_cert` as UCAP without a market-specific accreditation map. USD 500/MWh is not proof of an ordinary delivered-energy payment, and the ISO-NE scarcity settlement is not an all-event performance tariff. The declared `0–1000 USD/kW-y` and `0–50 USD/MWh` grids remain research coordinates, not observed US market ranges.

### 4.9 Flexible interconnection

**Primary evidence**

- **INTERCONNECT-LBNL-2026 — Kahrl and Frick, _Speed to Power_.** The DOE/LBNL report catalogues more than 40 solutions for accelerating large-load connections, including staggered, static-limit and dynamic approaches. [LBNL report page](https://eta-publications.lbl.gov/publications/speed-power-solutions-accelerating)
- **INTERCONNECT-PGE-CPUC-2025 — PG&E CPUC filing.** Flex Connect offers dynamic hourly limits based on near-term forecasts as an interim bridge while network upgrades are completed. PG&E states that likely good fits are generally loads above 750 kW where added-capacity benefits exceed equipment-installation cost. [CPUC filing](https://docs.cpuc.ca.gov/PublishedDocs/Efile/G000/M569/K525/569525911.PDF)
- **INTERCONNECT-PGE-2026 — PG&E programme description.** PG&E reports that its Flex Connect deployments advanced projects by 18–24 months in many cases. This is a company-reported time-to-power observation, not a transferable dollar benefit. [PG&E](https://www.pge.com/en/newsroom/currents/future-of-energy/why-grid-flexibility-is-now-essential---and-how-p-g-e-is-deliveri.html)
- **INTERCONNECT-FERC-2026 — FERC Docket RM26-4.** FERC's large-load interconnection proceeding explicitly considers whether flexible loads that agree to curtail could connect faster and how upgrade costs should be allocated. It is an ongoing regulatory process, not a final generic tariff. [FERC docket](https://ferc.gov/rm26-4)

**Support level:** `context_only`  
**Replaceability:** `not_convertible`

**Allowed interpretation:** Flexible interconnection is a real, policy-relevant mechanism that can create earlier energization or avoid/defer upgrades in particular constrained projects.

**Forbidden interpretation:** Do not convert 18–24 months into a generic annual dollar value, treat a programme eligibility heuristic as a market price, or use an illustrative connection limit as certified DR capacity. A monetary value must be project-specific: avoided/deferred upgrade cost plus earlier operating cash flow, minus control, curtailment, reliability and compliance cost. It must also be kept separate from capacity-market revenue to avoid double counting.

**Model decision:** The zero base value is appropriate until a named-site interconnection counterfactual exists.

### 4.10 Electricity price

**Primary evidence**

- **ENERGY-EIA-2026 — EIA Electric Power Monthly, Table 5.3.** Preliminary 2025 US average end-use prices were 8.62 cents/kWh for industrial customers and 13.41 cents/kWh for commercial customers. The 2026 year-to-date averages through June were 8.89 and 13.86 cents/kWh respectively. [EIA Table 5.3](https://www.eia.gov/electricity/monthly/epm_table_grapher.php?t=table_5_03)

**Support level:** `direct_market_observation`  
**Replaceability:** `sensitivity_only`

**Allowed interpretation:** USD 0.10/kWh lies within the broad national industrial-to-commercial average band and is defensible as a screening coordinate.

**Forbidden interpretation:** It is not a data-centre tariff, wholesale LMP, real-time price, coincident-peak charge or demand charge. It cannot support a location-specific bill-saving claim.

## 5. What may be used in the main text

The main text should use only the following external observations, and only with their scope stated:

1. one named capacity-market observation as a comparison to the computed break-even boundary;
2. the statement that public server accounting lives span several years, with detailed values in SI;
3. the existence of flexible-interconnection programmes as a potential value channel, without assigning a generic dollar value.

All cloud list prices, whole-server procurement values, checkpoint overhead ranges, old automated-DR control costs, WACC ranges, energy-price averages and alternative market products belong in Methods or Supplementary Information. They are useful for sensitivity design and reviewer transparency, but they are not the central causal result.

## 6. Required conditions before any parameter is called calibrated

| Parameter | Additional evidence required |
| --- | --- |
| Reserved capacity | Target hardware purchase/lease scope; measured controllable power at PCC; PUE; usable reserve fraction; baseline utilization; currency and inflation conversion. |
| Compute value | Operator contract or internal contribution-margin ledger; utilization; recovery versus displacement; variable energy/operations cost; SLA/service-credit exposure. |
| Delay and missed work | Workload-specific business value or service contract; lateness curve; cancellation and deadline consequences. |
| Checkpoint | Target model/framework/storage measurements; checkpoint frequency; interruption timing; recovered versus repeated work; dollar value of lost time. |
| Enablement | Site design/quote; telemetry and cyber requirements; market-registration cost; capex versus recurring opex; economic life. |
| Market payment/penalty | One named programme; eligibility; accreditation; baseline/M&V; availability window; settlement interval; capacity/performance/penalty and stop-loss terms. |
| Flexible interconnection | Named utility/site study; constrained and firm alternatives; upgrade scope; energization dates; curtailment envelope; lost-load value; double-counting check. |
| Electricity | Named tariff or settlement node; energy and demand charges; event timing; taxes and riders. |

Until those conditions are met, the defensible paper claim is a **break-even boundary over declared sensitivities**, not observed profitability.

## 7. Audit notes

- Retrieval date for all web sources: 2026-09-04.
- Monetary observations remain in their original nominal currency/year or current list-price basis in this register. They have not been silently converted to `real_2026_usd`.
- A public source can be authoritative and still be non-transferable. Authority establishes what the source actually observed; it does not establish scope equivalence to this data centre.
- The evidence search prioritised regulator, system-operator, government laboratory, official statistics, audited filing and first-party vendor sources. No unrelated Nature-family article was added merely to increase citation count.
