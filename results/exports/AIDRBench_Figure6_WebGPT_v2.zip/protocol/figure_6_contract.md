# Figure 6 contract: economic participation

## Claim contract

**Core conclusion.** Technical qualification is necessary but not sufficient
for economic participation: fixed site enablement is diluted by accounting
scale, whereas reserve and displaced-compute costs depend on distinct operator
mechanisms.

**Evidence class.** Development parameterized screening in real 2026 USD,
conditioned on an independently certified reference-module ceiling. No panel
is an economic locked-ID certificate or a named-market profitability estimate.

**Archetype.** Asymmetric four-panel quantitative figure. Panel a is the hero
scale result; panels b–d establish mechanism sensitivity, accounting closure
and the duration/technical-scope bridge.

**Rendering route.** Formal artwork is produced only in the web GPT from the
hash-verified source-data package. A repository-side renderer may validate the
data contract in tests but is not authorised to generate or publish the formal
artwork.

**Target/output.** Nature Communications double-column figure, 183 mm wide,
white background; editable SVG and PDF, 600 dpi LZW TIFF, PNG preview and the
web GPT's reproducible plotting record. Primary text is at least 7 pt and
secondary text at least 6.5 pt at final size.

## Panel map and evidence logic

| Panel | Unique question | Exact source-data table | Required evidence |
| --- | --- | --- | --- |
| a | How does one fixed site cost change the risk-adjusted break-even payment across proportional accounting scales? | `fig6_fixed_site_overlay_scale_sensitivity` | Every regime × site scale × fixed-cost perspective row |
| b | Which predeclared regime-specific driver changes the risk-adjusted threshold? | `fig6_mechanism_sensitivity` | Plausible versus stress event counts; economic life; effective `alpha × v` |
| c | Which signed costs and credits close exactly to the risk-adjusted break-even total? | `fig6_break_even_decomposition` | Separate fixed and variable enablement components plus all other zero/non-zero rows |
| d | How does compensation change by independently certified duration, and what is reference-certificate versus 1 MW accounting scope? | `fig6_duration_break_even` | Mean-style lower bound, full-overlay risk rule, reference and scaled-accounting capacity labels |

`fig6_technical_economic_boundary` remains a supporting audit table. It is not
the panel-a input after the fixed-site scale correction.

## Evidence hierarchy

1. **Reference technical ceiling:** the prior causal certificate fixes
   `technical_capacity_ceiling_kw`; no economic assumption changes it.
2. **Physical event evidence:** paired no-DR and fixed-controller development
   replays preserve matched jobs, community profile, event and seed.
3. **Accounting copies:** `scaled_accounting_*` quantities proportionally copy
   the reference module to declared site-scale coordinates with no portfolio
   diversification. They are not new technical certificates.
4. **Economic result:** fresh-event bootstrap annualization evaluates explicit
   cost/payment coordinates. The fifth percentile is a decision risk rule, not
   inferential uncertainty on a population parameter.
5. **External anchors:** authoritative observations bound or contextualize
   selected axes. Their permitted-use fields govern interpretation; they do
   not automatically become model point estimates.
6. **Physical reserve mapping:** event-end paired backlog debt is translated
   into a recovery-throughput-equivalent GPU count and explicit IT/facility
   power layers in a Supplementary sensitivity. Capital cost remains disabled.

## Identities and invariants

The web GPT must verify these before plotting:

```text
candidate_reduction_kw == technical_capacity_ceiling_kw
scaled_accounting_candidate_reduction_kw
    == scaled_accounting_technical_capacity_ceiling_kw
technical_qualification == independently_certified_ceiling
```

For each panel-c regime:

```text
sum(contribution_per_kw_year)
    == risk_adjusted_break_even_capacity_payment_per_kw_year
```

within `1e-6 real-2026-USD kW^-1 year^-1`.

For panel d, `technical_capacity_ceiling_kw` and
`scaled_accounting_technical_capacity_ceiling_kw` must each be identical
across the three regime rows at a given duration. The former is the reference
certificate; the latter is a 1 MW proportional accounting coordinate.

The enablement identity is:

```text
C_enable = I(K_offer > 0) * C_fixed,site + c_variable * K_offer
```

Panel c must therefore retain separate `fixed_site_enablement_cost` and
`variable_enablement_cost` components.

The displaced-compute coordinate is:

```text
effective_displaced_compute_value_per_gpu_h
    = opportunity_exposure_alpha * value_per_gpu_h
```

Panel b reports the product, not alpha alone.

## Annualization and event-frequency boundary

The screening samples independent, fully cleared event states. It is not a
continuous chronological programme. Annual event counts 1, 12 and 50 are
plausible screening coordinates. Counts 100 and 250 are exposure-multiplier
stress tests and must be visually distinguished and labelled as stress.

Repeated-event economics is a separately declared phase-2 analysis. It is not
silently inferred from this isolated fresh-event figure.

## Physical mapping boundary

Reserved-headroom capital in the main screening remains an abstract PCC-side
kW sensitivity coordinate. The Supplementary mapping reports a
**recovery-throughput-equivalent reserved GPU count** obtained from event-end
paired backlog debt, a recovery target and an execution efficiency. It is not:

- a required or firm GPU fleet;
- a purchase recommendation;
- a proof that those GPUs are electrically deliverable at the PCC;
- a certificate for a different accelerator type;
- an annualized hardware capital estimate.

Installed IT power, PUE-adjusted installed facility power and incremental
recovery dynamic facility power are separate columns and must not be mixed.

## Reviewer-facing risks and controls

| Risk | Required control |
| --- | --- |
| Fixed annual overhead dominates a small reference resource | Panel a shows both excluding-fixed lower bound and explicit fixed-site overlay across all declared scales |
| Scaled MW rows are mistaken for certified capacity | Every panel retains `technical_certificate_scope` and `facility_scale_interpretation`; panel d labels both scopes |
| Opportunity cost appears to depend only on alpha | Panel b uses `effective_displaced_compute_value_per_gpu_h = alpha × v` |
| Stress exposure is read as a realistic dispatch frequency | 100/250 are visibly marked `exposure_multiplier_stress` |
| Parameter sensitivities are read as market estimates | External register distinguishes numerical anchors, comparator bounds and unobserved sensitivities |
| Reserve kW is read as GPU procurement | Main panel calls it abstract PCC-side sensitivity; Supplementary mapping uses the recovery-throughput-equivalent term and disables capex |
| Cost stack hides arbitrary grouping | Panel c retains one row/mark per signed component and keeps fixed/variable enablement separate |
| Fifth percentile is mistaken for a confidence interval | Figure note calls it a bootstrap annual-net-value risk rule |
| Web GPT silently recomputes inputs | Manifest hash/column/row checks are mandatory; panel CSVs are already plot-ready |

## Deterministic visual encodings

- Regime colours: Slack-backed `#3D9B8F`; Reserved headroom `#776FA3`;
  Throughput-displacing `#D5634E`.
- Panel a perspective: including fixed site = solid/filled; excluding fixed
  site = dashed/open.
- Panel b annual-event status: plausible = filled circle; stress = open/crossed
  marker with direct “stress” label.
- Panel c sign: positive above zero, negative below zero; total = open diamond;
  zero component = explicit zero tick.
- Panel d: fixed-site-excluded mean-style lower bound = open circle; full
  fixed-site-overlay fifth-percentile rule = filled diamond.

Connecting segments are visual guides between declared coordinates, never
interpolated evidence.

## Package completeness

The distributable package contains the four panel CSVs, all supporting CSVs,
the source-data manifest, this contract, the field dictionary, the normalized
economic and reserve specifications and provenance manifests. File names are
ASCII and the ZIP uses a standard compression method so it can be opened on
Windows without repair.
