# Economic participation protocol v1

## Status and scope

This protocol governs `nature_economic_development_screening_v1`. It is a
parameterized development analysis, not a new economic certificate and not a
claim about a named market or operator. The previously frozen technical
certificate remains the upper bound `K_cert`; monetary assumptions cannot
change it.

The protocol is intentionally frozen before any new economic locked-ID split
is created. The existing locked-ID causal result is read only to obtain the
already certified technical ceiling. It is not replayed or reanalysed as an
economic holdout.

## Source- and lock-pinned compatibility replay

Physical trajectories are generated from the complete Git tree recorded by the
technical certificate (`5889405427b8f00f3cdd12b961b79d621b122e65`), not from
the current environment worktree. The bridge verifies the certificate source
hashes, controller configuration, full archived tree, calibration artifact,
`pyproject.toml`, `uv.lock`, installed solver/runtime versions and exact Python
runtime. The current process only performs paired economic accounting; its
technical outcome definition must remain byte-identical to the certificate.

The replay allowlist is the ordered set of 100 validation hashes stored in the
hash-bound q=0.95 selection. It is checked against the validation receipt and
must be disjoint from all 500 locked-ID hashes. Real paths and payload files are
checked before loading; symbolic links and any resolved locked scenario root
are rejected. The output records `locked_scenario_payloads_read=false` and
`locked_ood_read=false`.

This reconstructs a source- and declared-lock-compatible runtime. Because the
original certificate did not record a complete executable image, it is not
described as proof of bitwise identity to the original machine runtime.

## Primary estimand

For each participation regime, the primary quantity is the mean and
risk-adjusted break-even capacity payment at the independently certified
commitment `K_cert`. Version 1 admits only the binary main-text decision
`K_offer in {0, K_cert}`. Lower fractions, if retained for development QA, are
labelled `development_screened_not_independently_certified` and cannot define
`K_econ` or enter the main figure.

The primary case is a 4 h, zero-notice event at `q = 0.95`, 50 independent
fresh-event draws per year, the fixed robust MPC specification, and the
explicit base capital, operating and two-part payment cases in
`configs/economics/economic_participation_v1.yaml`.

The v1 duration grid is 2, 4 and 8 h. The 1 h cell is deliberately excluded:
the fixed q = 0.95 technical certificate has no independently certified 1 h
candidate that this protocol may treat as `K_cert`.

Both mean annual net value and its predeclared lower 5th-percentile bootstrap
value are reported. The latter is the risk rule. A continuous economic offer
curve is deliberately not claimed without independent technical qualification
of its intermediate capacities.

## Physical counterfactual

Every event uses the same immutable frozen scenario, episode seed, controller
configuration and event timing for two rollouts:

1. `no_control`, which executes the available fleet at full fraction;
2. fixed-specification robust MPC under the requested DR reduction.

The controlled trajectory's shadow baseline must equal the explicit
no-control PCC trajectory within the declared tolerance. Work conservation is
checked separately for both trajectories. The ledger preserves the exact
event, nominal-recovery and clearance-tail values used for each aggregate.

`backlog_at_recovery_stop_gpu_h` is a recovery-state compute-debt diagnostic.
It is not charged as terminal lost work. `terminal_backlog_gpu_h` and the
incremental missed-work total are measured over the complete clearance tail to
episode end, so work that is recovered after the nominal recovery window is not
mistakenly priced as permanent loss.

The paired ledger reports both time bases explicitly:

- `recovered_within_recovery_window_gpu_h` and
  `recovered_through_episode_end_gpu_h`;
- `incremental_backlog_area_within_recovery_gpu_h_h` and
  `incremental_backlog_area_through_episode_end_gpu_h_h`;
- `incremental_energy_within_recovery_kwh` and
  `incremental_energy_through_episode_end_kwh`.

Economic accounting always consumes the `through_episode_end` quantities.
Nominal-window quantities remain diagnostics of recovery speed.

## Economic accounting regimes

The three regimes are mutually exclusive.

| Regime | Incremental cost allowed | Cost expressly excluded |
| --- | --- | --- |
| Slack-backed | enablement, event/recovery energy, declared delay/service terms | reserved-capacity capital and displaced-compute value |
| Reserved headroom | annualized capital and O&M only for deliberately reserved capacity, plus enablement and event terms | displaced-compute value |
| Throughput-displacing | declared fraction of deferred work valued as displaced throughput, plus enablement and event terms | reserve capital |

Fleet-wide GPU depreciation is never charged per DR event. Missed-work and
terminal-backlog service prices cannot be combined with a throughput-displacement
term for the same work, preventing double counting.

Performance revenue is calculated from contract-capped delivery,
`sum_t min(max(P0_t - PDR_t, 0), K_offer) * dt`. Raw physical relief is retained
only as a diagnostic and cannot create payment above the contracted reduction.
Reserved capacity is an abstract PCC-side kW sensitivity coordinate in v1; it
is not presented as a measured GPU count or physical headroom requirement.

## Interpretation boundaries

- Cost and payment values in v1 are explicit research-design sensitivity
  coordinates. They are not vendor quotes, tariffs, cloud prices, or private
  operating margins.
- Independent fresh-event bootstrap captures variation across frozen event
  scenarios, not a chronological market dispatch programme or repeated-event
  fatigue. Repeated-event economics requires a separately frozen programme.
- The result may state a break-even payment coordinate and a parameterized
  `K_econ`; it may not state that a real operator will offer capacity until
  source-backed inputs and a new economic locked-ID evaluation are added.
- Demand charges, connection deferral and tax-adjusted NPV are excluded unless
  full chronological tariff and load data are preregistered.
- Economic-life sensitivity varies 3--6 years at fixed 8% WACC and 10%
  salvage. WACC and salvage are varied in separate orthogonal tables, so their
  effects are not conflated with lifetime.

## Required provenance

Each run writes the complete normalized protocol, source hashes, controller
and technical-certificate hashes, scenario hashes, code hashes, git state,
input units and analysis role. Source data export is hash-bound and every
Figure 6 panel consumes a declared table without manual spreadsheet edits.
The replay caches one no-control trajectory per scenario/duration/notice group,
commits each completed group atomically, resumes only under an identical
reservation hash, and publishes the final directory by atomic rename.
Economic evaluation, source-data export and figure generation likewise reject
an existing destination and atomically rename a complete staging directory.
Each panel CSV repeats the annualization, payment, reserve-basis and technical-
qualification fields needed to interpret it without consulting another file.
