# README FIRST — Web GPT contract for Supplementary Figure S5

The formal Supplementary Figure S5 artwork must be produced in the web GPT
from the four supplied CSV files. Do not use the repository's former Main
Figure 6 image as artwork, and do not add a map: the three cases are climate-zone
load-profile archetypes, not named, geocoded or measured data-centre sites.

## Integrity gate

Before drawing:

1. Open `source_data/s5_panel_data_manifest.json`.
2. Verify the SHA-256, row count and ordered columns of all four CSV files.
3. Stop if any file is missing or mismatched.
4. Do not change, interpolate, smooth, aggregate or impute a supplied value.

## Exact file map

| Panel | File | Rows |
| --- | --- | ---: |
| a | `source_data/figure_s5_panel_a.csv` | 504 |
| b | `source_data/figure_s5_panel_b.csv` | 24 |
| c | `source_data/figure_s5_panel_c.csv` | 6 |
| d | `source_data/figure_s5_panel_d.csv` | 12 |

Read `protocol/figure_s5_contract.md` before plotting. Every mark must trace to
one row and named field in its panel CSV.

## Scientific conclusion

Holding jobs, hardware, events and random seeds fixed, changing only the EULP
3A, 3C or 5A community profile leaves the q = 0.95 job-derived firm-capacity
surface and the fixed-controller success counts unchanged in this development
sensitivity. The absolute PV-hosting boundary and the rigid-to-flexible
increment remain profile- and BESS-dependent. This separates technical
resource qualification from its local system value.

## Shared encodings

Use a colour-blind-safe, low-saturation palette and keep it fixed:

- 3A: `#3D9B8F`
- 3C: `#776FA3`
- 5A: `#D5634E`
- rigid operation: open marker
- flexible operation: filled marker
- no BESS: circle
- BESS: square

Use dark ink `#24313D`, neutral grey `#75808A` and light grid lines `#DCE2E6`.
Final width is 183 mm, with editable SVG/PDF, 600-dpi LZW TIFF, PNG preview and
the generation record returned by the web GPT.

## Non-negotiable claim boundaries

- Panels b and c are non-locked development diagnostics.
- Panel d is a perfect-information planning result, not a causal-controller effect.
- H = 5 h and H = 7 h were not evaluated; do not draw markers or values there.
- A connecting line is only a visual guide and cannot create missing estimates.
- Coincident curves in panel b must be described as invariance, not hidden data.
- Do not infer that community profiles never matter outside this paired Model A test.
- Do not infer a city, geography or feeder from the climate-zone labels.

Return an error report instead of artwork if any integrity or claim-boundary
check cannot be satisfied.
