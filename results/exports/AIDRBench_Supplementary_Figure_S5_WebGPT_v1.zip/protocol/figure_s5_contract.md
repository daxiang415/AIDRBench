# Supplementary Figure S5 contract

## Title

**Community profiles condition system value but not job-derived firm capacity**

## Evidence class

Paired development sensitivity. Jobs, hardware, event streams and random seeds
are held fixed across EULP 3A, 3C and 5A profile archetypes. No locked scenario
is reopened. The figure supports an attribution boundary, not a geographical
survey.

## Panel a — community context

Use all 504 rows in `figure_s5_panel_a.csv`.

- x: `elapsed_day` or `elapsed_hour`
- y: `net_community_load_kw`
- colour: `climate_zone`
- exactly 168 chronological hours per zone
- no smoothing, resampling or selected-week substitution

Question: do the paired community contexts differ before the job-derived
resource is evaluated?

## Panel b — firm-capacity invariance

Use all 24 rows in `figure_s5_panel_b.csv` to construct the complete 1–8-h
display grid, but draw data markers only where
`duration_grid_status=evaluated`.

- x: `duration_h`, show ticks 1 through 8
- y: `perfect_information_firm_capacity_kw`
- colour/marker: `climate_zone`
- evaluated H: 1, 2, 3, 4, 6 and 8 h
- H = 5 and 7 h: explicitly mark as “not evaluated”; never assign a y value

The three evaluated curves coincide to numerical precision. Use distinct
marker outlines or slight visual layering so all three source series remain
auditable without inventing an offset. State that the maximum profile spread
at the reported boundary is zero.

## Panel c — fixed-controller development transfer

Use all six rows in `figure_s5_panel_c.csv`.

- x: categorical `duration_h` at 4 and 8 h
- y: success fraction
- filled marker: `empirical_success_fraction`
- open marker: `wilson_lower_confidence_bound`
- colour: `climate_zone`
- show the q = 0.95 horizontal target

Each point represents 100 development episodes. Do not label a point as a new
certificate. The Wilson value is a one-sided 95% lower bound, not an error bar
around the empirical fraction.

## Panel d — profile-dependent PV-hosting value

Use all 12 rows in `figure_s5_panel_d.csv`.

- y rows: `climate_zone` crossed with `bess_enabled`
- x: `simultaneous_feasible_pv_hosting_kw`
- open endpoint: `dc_operation=rigid`
- filled endpoint: `dc_operation=flexible`
- connect only the rigid/flexible pair within the same zone and BESS state
- encode BESS by marker shape or row label, not by reusing climate-zone colour

Every row is an all-scenario boundary over 100 planning scenarios. Do not use
`mean_scenario_pv_hosting_kw` as the plotted primary endpoint and do not call
the connecting segment a causal effect.

## Exact legend

**Supplementary Fig. S5 | Community profiles condition system value but not
job-derived firm capacity.** **a,** Earliest 168 chronological hours of net
community demand for each paired EULP climate-zone archetype (3A, 3C and 5A),
with no smoothing. **b,** q = 0.95 perfect-information tolerance lower bound
over 100 paired development scenarios per zone at the six evaluated durations.
H = 5 h and H = 7 h are explicitly unevaluated rather than interpolated.
**c,** Development replay of the fixed validation-selected causal-controller
candidates at H = 4 h and H = 8 h (n = 100 independent episodes per zone and
duration). Filled markers denote empirical success fractions and open markers
denote one-sided 95% Wilson lower bounds. **d,** All-scenario feasible
PV-hosting boundaries under rigid and flexible workload scheduling, with and
without BESS (100 scenarios per design cell). Jobs, hardware, events and random
seeds are paired across profiles. The profiles are archetypes rather than named
or geocoded sites; panels b and c are non-locked development diagnostics, and
panel d is a perfect-information planning result rather than a causal-controller
effect.

## Delivery QA

- four panels labelled a–d;
- minimum 7-pt primary and 6.5-pt secondary text at 183 mm;
- no maps, decorative icons, gradients, 3-D effects or hidden interpolation;
- all labels editable and unclipped;
- return SVG, PDF, 600-dpi LZW TIFF, PNG and the exact generation record;
- do not overwrite any supplied CSV or manifest.
